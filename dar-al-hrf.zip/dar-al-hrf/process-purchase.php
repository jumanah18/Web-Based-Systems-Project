<?php
// Ghada Alsubaie
session_start();
require 'db.php';

// If the cart is empty, send them back to the checkout page
if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
    header('Location: checkout.php');
    exit;
}

$cartSnapshot = array_values($_SESSION['cart']); 

$existing = [];
if (isset($_COOKIE['dh_purchases'])) {
    $decoded = json_decode($_COOKIE['dh_purchases'], true);
    if (is_array($decoded)) {
        $existing = $decoded;
    }
}

$newPurchase = [
    'date'  => date('d/m/Y'),
    'items' => $cartSnapshot
];
$existing[] = $newPurchase;

if (count($existing) > 20) {
    $existing = array_slice($existing, -20);
}

setcookie(
    'dh_purchases',
    json_encode($existing),
    time() + (30 * 24 * 60 * 60),
    '/',
    '',
    false,
    false
);

foreach ($_SESSION['cart'] as $item) {
    $type      = isset($item['type']) ? $item['type'] : 'product';
    $qtyBought = isset($item['qty']) ? (int)$item['qty'] : 1;

    $rawId     = isset($item['id']) ? $item['id'] : (isset($item['pid']) ? $item['pid'] : 0);
    $productId = (int)$rawId; 

    if ($productId <= 0 || $qtyBought <= 0) continue;

    if ($type === 'workshop') {
        $stmt = $pdo->prepare("
            UPDATE products
            SET quantity = GREATEST(0, quantity - ?)
            WHERE pid = ? AND category = 'Workshop'
        ");
        $stmt->execute([$qtyBought, $productId]);

        try {
            $stmtSeats = $pdo->prepare("
                UPDATE products
                SET seats = GREATEST(0, seats - ?)
                WHERE pid = ? AND category = 'Workshop'
            ");
            $stmtSeats->execute([$qtyBought, $productId]);
        } catch (PDOException $e) {
        }
    } else {
        $stmt = $pdo->prepare("
            UPDATE products
            SET quantity = GREATEST(0, quantity - ?)
            WHERE pid = ? AND category != 'Workshop'
        ");
        $stmt->execute([$qtyBought, $productId]);
    }
}

// Clear the cart session
$_SESSION['cart'] = [];

header('Location: purchase-completed.php');
exit;
?>
