<?php
// process-purchase.php
session_start();
require 'db.php';

// If the cart is empty, send them back to the checkout page
if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
    header('Location: checkout.php');
    exit;
}

// ── Save cart to cookie for past purchases BEFORE clearing session ────────────
$cartSnapshot = array_values($_SESSION['cart']); // normalize to indexed array

$existing = [];
if (isset($_COOKIE['dh_purchases'])) {
    $decoded = json_decode($_COOKIE['dh_purchases'], true);
    if (is_array($decoded)) {
        $existing = $decoded;
    }
}

$newPurchase = [
    'date'  => date('d/m/Y'),
    'items' => $cartSnapshot
];
$existing[] = $newPurchase;

// Keep only last 20 purchases so the cookie doesn't grow unbounded
if (count($existing) > 20) {
    $existing = array_slice($existing, -20);
}

setcookie(
    'dh_purchases',
    json_encode($existing),
    time() + (30 * 24 * 60 * 60),
    '/',
    '',
    false,
    false
);

// ── Update product stock / seat counts in database ───────────────────────────
foreach ($_SESSION['cart'] as $item) {
    $type      = isset($item['type']) ? $item['type'] : 'product';
    $qtyBought = isset($item['qty']) ? (int)$item['qty'] : 1;

    // Extract the numeric product ID (workshop IDs are like "5_0", product IDs are integers)
    $rawId     = isset($item['id']) ? $item['id'] : (isset($item['pid']) ? $item['pid'] : 0);
    $productId = (int)$rawId; // "5_0" -> 5, "12" -> 12

    if ($productId <= 0 || $qtyBought <= 0) continue;

    if ($type === 'workshop') {
        // Decrement quantity (available seats), never below 0
        $stmt = $pdo->prepare("
            UPDATE products
            SET quantity = GREATEST(0, quantity - ?)
            WHERE pid = ? AND category = 'Workshop'
        ");
        $stmt->execute([$qtyBought, $productId]);

        // Also try to decrement seats column if it exists
        try {
            $stmtSeats = $pdo->prepare("
                UPDATE products
                SET seats = GREATEST(0, seats - ?)
                WHERE pid = ? AND category = 'Workshop'
            ");
            $stmtSeats->execute([$qtyBought, $productId]);
        } catch (PDOException $e) {
            // seats column may not exist in all DB versions — quantity was already decremented above
        }
    } else {
        // Decrement product stock, never below 0
        $stmt = $pdo->prepare("
            UPDATE products
            SET quantity = GREATEST(0, quantity - ?)
            WHERE pid = ? AND category != 'Workshop'
        ");
        $stmt->execute([$qtyBought, $productId]);
    }
}

// Clear the cart session
$_SESSION['cart'] = [];

header('Location: purchase-completed.php');
exit;
?>
