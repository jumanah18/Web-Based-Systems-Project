<?php
// Ghada Alsubaie
session_start();
require 'db.php';

$data = json_decode(file_get_contents('php://input'), true);

if (!$data || !isset($data['id'])) {
    echo json_encode(['success' => false, 'message' => 'Invalid data provided.']);
    exit;
}

$type      = isset($data['type']) ? $data['type'] : 'product';
$chosenQty = isset($data['qty']) ? (int)$data['qty'] : 1;

if ($chosenQty < 1) {
    echo json_encode(['success' => false, 'message' => 'Quantity must be at least 1.']);
    exit;
}

if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

if ($type === 'workshop') {
    $cartId = (string)$data['id']; 

    $found = false;
    for ($i = 0; $i < count($_SESSION['cart']); $i++) {
        if ((string)$_SESSION['cart'][$i]['id'] === $cartId) {
            $_SESSION['cart'][$i]['qty'] += $chosenQty;
            $found = true;
            break;
        }
    }

    if (!$found) {
        $_SESSION['cart'][] = [
            'id'      => $cartId,
            'name'    => $data['name']    ?? 'Workshop',
            'price'   => (float)($data['price']   ?? 0),
            'image'   => $data['image']   ?? '',
            'artisan' => $data['artisan'] ?? 'Dar Al Hiraf Artisan',
            'type'    => 'workshop',
            'qty'     => $chosenQty
        ];
    }

    echo json_encode(['success' => true]);
    exit;
}

$id = (int)$data['id'];

$stmt = $pdo->prepare("SELECT quantity FROM products WHERE pid = ? AND category != 'Workshop'");
$stmt->execute([$id]);
$product = $stmt->fetch();

if (!$product) {
    echo json_encode(['success' => false, 'message' => 'Product not found.']);
    exit;
}

$dbStock   = (int)$product['quantity'];
$targetQty = $chosenQty;
$alreadyInCart = false;

for ($i = 0; $i < count($_SESSION['cart']); $i++) {
    if ((string)$_SESSION['cart'][$i]['id'] === (string)$id) {
        $alreadyInCart = true;
        $targetQty = $_SESSION['cart'][$i]['qty'] + $chosenQty;

        if ($targetQty > $dbStock) {
            echo json_encode([
                'success' => false,
                'message' => "Cannot add more. You already have " . $_SESSION['cart'][$i]['qty'] . " in your cart, and maximum available stock is " . $dbStock . "."
            ]);
            exit;
        }

        $_SESSION['cart'][$i]['qty'] = $targetQty;
        break;
    }
}

if (!$alreadyInCart) {
    if ($targetQty > $dbStock) {
        echo json_encode(['success' => false, 'message' => "Requested quantity exceeds available stock ($dbStock left)."]);
        exit;
    }

    $_SESSION['cart'][] = [
        'id'      => $id,
        'name'    => $data['name']    ?? '',
        'price'   => (float)($data['price']   ?? 0),
        'image'   => $data['image']   ?? '',
        'artisan' => $data['artisan'] ?? '',
        'type'    => 'product',
        'qty'     => $chosenQty
    ];
}

echo json_encode(['success' => true]);
?>
