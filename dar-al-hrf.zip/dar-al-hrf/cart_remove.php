<?php
// Ghada Alsubaie
if (session_status() === PHP_SESSION_NONE) { session_start(); }

header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);
if (!$data) {
    echo json_encode(['success' => false, 'message' => 'No data received.']);
    exit;
}

if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
    echo json_encode(['success' => true]);
    exit;
}

if (isset($data['cart_index'])) {
    $_SESSION['cart'] = array_values($_SESSION['cart']);
    $idx = (int)$data['cart_index'];
    if (isset($_SESSION['cart'][$idx])) {
        array_splice($_SESSION['cart'], $idx, 1);
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Item not found.']);
    }
    exit;
}

$targetId = '';
if (isset($data['id'])       && $data['id']       !== '') { $targetId = trim((string)$data['id']); }
elseif (isset($data['cart_key']) && $data['cart_key'] !== '') { $targetId = trim((string)$data['cart_key']); }

foreach ($_SESSION['cart'] as $key => $item) {
    $itemId = '';
    if (isset($item['id'])  && $item['id']  !== '') { $itemId = (string)$item['id']; }
    elseif (isset($item['pid']) && $item['pid'] !== '') { $itemId = (string)$item['pid']; }
    if ($itemId === $targetId) {
        unset($_SESSION['cart'][$key]);
        $_SESSION['cart'] = array_values($_SESSION['cart']);
        echo json_encode(['success' => true]);
        exit;
    }
}

echo json_encode(['success' => false, 'message' => 'Item not found.']);
exit;
?>
