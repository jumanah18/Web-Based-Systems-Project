<?php
session_start();
//Habiba Alsubiani

$data   = json_decode(file_get_contents('php://input'), true);
$action = isset($data['action']) ? $data['action'] : '';
$qty    = isset($data['qty'])    ? (int)$data['qty'] : null;

if (!isset($_SESSION['cart'])) { $_SESSION['cart'] = []; }

$cartChanged = false;

if ($action === 'clear_all') {
    $_SESSION['cart'] = [];
    $cartChanged = true;

} elseif (isset($data['cart_index'])) {
    $idx = (int)$data['cart_index'];
    $_SESSION['cart'] = array_values($_SESSION['cart']);
    if (isset($_SESSION['cart'][$idx])) {
        if ($qty !== null && $qty > 0) {
            $_SESSION['cart'][$idx]['qty'] = $qty;
            $cartChanged = true;
        } elseif ($action === 'delete' || ($qty !== null && $qty <= 0)) {
            array_splice($_SESSION['cart'], $idx, 1);
            $cartChanged = true;
        }
    }

} elseif (isset($data['id'])) {
    $targetId = (string)$data['id'];
    foreach ($_SESSION['cart'] as $key => $item) {
        $itemId = '';
        if (isset($item['id'])  && $item['id']  !== '') { $itemId = (string)$item['id']; }
        elseif (isset($item['pid']) && $item['pid'] !== '') { $itemId = (string)$item['pid']; }
        if ($itemId === $targetId) {
            if ($action === 'delete' || ($qty !== null && $qty <= 0)) {
                unset($_SESSION['cart'][$key]);
                $cartChanged = true;
            } elseif ($qty !== null) {
                $_SESSION['cart'][$key]['qty'] = $qty;
                $cartChanged = true;
            }
            break;
        }
    }
}

if ($cartChanged) { $_SESSION['cart'] = array_values($_SESSION['cart']); }

// Calculate totals
$productsSubtotal  = 0;
$workshopsSubtotal = 0;
foreach ($_SESSION['cart'] as $item) {
    $val = (float)$item['price'] * (int)$item['qty'];
    if (isset($item['type']) && $item['type'] === 'workshop') { $workshopsSubtotal += $val; }
    else { $productsSubtotal += $val; }
}
$serviceFee = 15;
$grandTotal = $productsSubtotal + $workshopsSubtotal + $serviceFee;

header('Content-Type: application/json');
echo json_encode([
    'success'           => true,
    'productsSubtotal'  => number_format($productsSubtotal,  2),
    'workshopsSubtotal' => number_format($workshopsSubtotal, 2),
    'grandTotal'        => number_format($grandTotal, 2)
]);
exit;
?>
