<?php
session_start();

if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

// Normalize: always re-index and ensure every item has an 'id' field
$normalized = [];
foreach ($_SESSION['cart'] as $item) {
    // If item has pid but no id, set id from pid
    if (!isset($item['id']) || $item['id'] === '') {
        if (isset($item['pid']) && $item['pid'] !== '') {
            $item['id'] = (string)$item['pid'];
        }
    }
    $normalized[] = $item;
}

echo json_encode(['success' => true, 'cart' => $normalized]);
?>
