<?php
// Ghada alsubaie
session_start();

if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

$normalized = [];
foreach ($_SESSION['cart'] as $item) {
    if (!isset($item['id']) || $item['id'] === '') {
        if (isset($item['pid']) && $item['pid'] !== '') {
            $item['id'] = (string)$item['pid'];
        }
    }
    $normalized[] = $item;
}

echo json_encode(['success' => true, 'cart' => $normalized]);
?>
