<?php
// Alhanouf Aldossari

require_once 'db.php';
$stmt = $pdo->query("SELECT * FROM products");
$allProducts = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Dar Al Hiraf — Search Results | نتائج البحث</title>
  <link rel="stylesheet" href="style.css" />
</head>
<body>

<nav class="navbar">
  <div class="navbar-inner">
    <a href="index.php" class="navbar-logo">
      <span class="logo-ar">دار الحرف</span>
      <span class="logo-en">Dar Al Hiraf</span>
    </a>
    <div class="navbar-nav">
      <a href="index.php">Home</a>
      <a href="shop.php">Shop</a>
      <a href="workshops.php">Workshops</a>
      <a href="about.html">About</a>
    </div>
    <form class="navbar-search" onsubmit="event.preventDefault();var v=this.querySelector('input').value.trim();if(v)window.location.href='search.php?q='+encodeURIComponent(v);" role="search">
      <input class="navbar-search-input" type="search" placeholder="Search..." aria-label="Search">
      <button class="navbar-search-btn" type="submit" aria-label="Search">
        <svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
      </button>
    </form>
    
        <div class="navbar-right">
      <a id="adminNavLink" href="admin-login.php" class="navbar-admin-link">Admin</a>
      <a href="checkout.php" class="navbar-cart-btn" id="cartBtn" aria-label="View cart">
        <svg viewBox="0 0 24 24" aria-hidden="true" width="18" height="18" stroke="#1a1a1a" fill="none" stroke-width="2"><path d="M6 2L3 6v14a2 2 0 002 2h14a2 2 0 002-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 01-8 0"/></svg>
        <span class="cart-badge" id="cartBadge"></span>
      </a>
    </div>
  </div>
</nav>

</div>

<div class="breadcrumb">
  <div class="breadcrumb-row">
    <a href="index.php">Home</a>
    <span class="bc-sep">/</span>
    <span class="bc-current">Search Results</span>
  </div>
</div>

<div class="search-container">
  
  <div class="search-header">
    <h1>ابحث عن الحرف اليدوية</h1>
    <h2>Search for authentic Saudi handicrafts</h2>
    <div class="search-box-wrapper">
      <input type="text" id="searchPageInput" class="search-box" placeholder="Search products, artisans, or workshops...">
      <button onclick="performPageSearch()" class="search-btn">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <circle cx="11" cy="11" r="8"></circle>
          <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
        </svg>
      </button>
    </div>
  </div>

  <div class="results-info" id="resultsInfo">
    <div class="results-count" id="resultsCount">Loading results...</div>
    <select class="sort-select" id="sortSelect">
      <option value="relevance">Sort by: Relevance</option>
      <option value="price_asc">Price: Low to High</option>
      <option value="price_desc">Price: High to Low</option>
    </select>
  </div>

  <div class="search-layout">
    
    <aside class="filters-sidebar">
      <div class="filter-title">تصفية النتائج</div>
      <div class="filter-title-en">FILTERS</div>

      <div class="filter-group">
        <span class="filter-group-label">Type</span>
        <div class="filter-options">
          <label class="filter-option"><input type="checkbox" id="filterProducts" value="product" checked> Products</label>
          <label class="filter-option"><input type="checkbox" id="filterWorkshops" value="workshop" checked> Workshops</label>
        </div>
      </div>

      <div class="filter-group">
        <span class="filter-group-label">Category</span>
        <div class="filter-options" id="categoryFilters">
          <?php
          $cats = $pdo->query("SELECT DISTINCT category FROM products ORDER BY category ASC")->fetchAll();
          foreach ($cats as $cat):
          ?>
          <label class="filter-option">
            <input type="checkbox" value="<?php echo htmlspecialchars($cat['category']); ?>" checked>
            <?php echo htmlspecialchars($cat['category']); ?>
          </label>
          <?php endforeach; ?>
        </div>
      </div>

      <div class="filter-group">
        <span class="filter-group-label">Price Range (SAR)</span>
        <div class="price-range">
          <input type="number" id="minPrice" placeholder="Min" class="price-input" value="0">
          <input type="number" id="maxPrice" placeholder="Max" class="price-input" value="2000">
        </div>
      </div>

      <div class="filter-group">
        <span class="filter-group-label">Artisan</span>
        <div class="filter-options" id="artisanFilters">
        <?php
        $artisans = $pdo->query("SELECT DISTINCT artisan FROM products WHERE artisan IS NOT NULL ORDER BY artisan ASC")->fetchAll();
        foreach ($artisans as $a):
        ?>
        <label class="filter-option">
          <input type="checkbox" value="<?php echo htmlspecialchars($a['artisan']); ?>" checked>
          <?php echo htmlspecialchars($a['artisan']); ?>
        </label>
        <?php endforeach; ?>
</div>
      </div>

      <button class="filter-btn" onclick="applyFilters()">Apply Filters</button>
      <div class="reset-filters">
        <a href="#" onclick="resetFilters(); return false;">Reset all filters</a>
      </div>
    </aside>

    <div>
      <div class="search-products-grid" id="resultsGrid"></div>
    </div>
  </div>

</div>

<footer class="footer">
  <div class="container">
    <div class="footer-grid">
      <div>
        <p class="footer-brand-name">دار الحرف</p>
        <p class="footer-desc">A platform connecting Saudi artisans with those who cherish authentic handmade crafts rooted in heritage. Proudly part of The Year of Handicrafts 2026 initiative by the Ministry of Culture.</p>
      </div>
      <div>
        <p class="footer-col-title">Shop</p>
        <div class="footer-links" role="list">
          <a href="shop.php">All Products</a>
          <a href="shop.php">Pottery</a>
          <a href="shop.php">Textiles</a>
          <a href="shop.php">Metalwork</a>
          <a href="shop.php">Leather</a>
          <a href="shop.php">Fragrance</a>
        </div>
      </div>
      <div>
        <p class="footer-col-title">More</p>
        <div class="footer-links">
          <a href="about.html">About Us</a>
          <a href="contact.php">Contact Us</a>
          <a href="workshops.php">Workshops</a>
          <a href="search-results.html">Search</a>
        </div>
      </div>
      </div>
    </div>
  </div>
  <div class="footer-gold-bar"></div>
  <div class="container">
    <div class="footer-bottom">
      <p>© 2026 Dar Al Hiraf — دار الحرف. All rights reserved.</p>
      <p>A Ministry of Culture Initiative</p>
    </div>
  </div>
</footer>

<script>
  const searchDatabase = <?php
$jsData = [];
foreach ($allProducts as $p) {
    $isWorkshop = $p['category'] === 'Workshop';
    $jsData[] = [
        'type'     => $isWorkshop ? 'workshop' : 'product',
        'name'     => $p['name'],
        'nameAr'   => '',
        'category' => $p['category'],
        'artisan'  => $p['artisan'],
        'price'    => (float)$p['price'],
        'image' => $p['image'],
        'link'     => $isWorkshop ? 'workshop.php?id=' . $p['pid'] : 'product.php?id=' . $p['pid'],
        'location' => $p['location'] ?? '',
        'keywords' => explode(' ', strtolower($p['name']))
    ];
}
echo json_encode($jsData);
?>;

  let currentSearchTerm = '';
  let currentResults = [];

  function getSearchTermFromURL() {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get('q') || '';
  }

  function performSearch(searchTerm) {
    if (!searchTerm || searchTerm.trim() === '') return [];
    const lowerTerm = searchTerm.toLowerCase().trim();
    const results = [];
    for (const item of searchDatabase) {
      let score = 0;
      if (item.name.toLowerCase() === lowerTerm) score += 10;
      if (item.name.toLowerCase().includes(lowerTerm)) score += 5;
      if (item.nameAr.toLowerCase().includes(lowerTerm)) score += 5;
      if (item.category.toLowerCase().includes(lowerTerm)) score += 4;
      if (item.artisan && item.artisan.toLowerCase().includes(lowerTerm)) score += 4;
      if (item.location && item.location.toLowerCase().includes(lowerTerm)) score += 4;
      for (const kw of item.keywords) {
        if (kw.includes(lowerTerm)) score += 3;
        if (lowerTerm.includes(kw)) score += 2;
      }
      if ((lowerTerm === 'workshop' || lowerTerm === 'workshops') && item.type === 'workshop') score += 8;
      if ((lowerTerm === 'product' || lowerTerm === 'products') && item.type === 'product') score += 8;
      const words = lowerTerm.split(' ');
      for (const word of words) {
        if (word.length > 2 && item.name.toLowerCase().includes(word)) score += 2;
      }
      if (score > 0) results.push({ ...item, relevanceScore: score });
    }
    results.sort((a, b) => b.relevanceScore - a.relevanceScore);
    return results;
  }

  function applyFilters() {
    let filtered = [...currentResults];
    const showProducts = document.getElementById('filterProducts').checked;
    const showWorkshops = document.getElementById('filterWorkshops').checked;
    filtered = filtered.filter(item => (item.type === 'product' && showProducts) || (item.type === 'workshop' && showWorkshops));
    const selectedCategories = Array.from(document.querySelectorAll('#categoryFilters input:checked')).map(cb => cb.value);
    if (selectedCategories.length > 0) filtered = filtered.filter(item => selectedCategories.includes(item.category));
    const minPrice = parseInt(document.getElementById('minPrice').value) || 0;
    const maxPrice = parseInt(document.getElementById('maxPrice').value) || Infinity;
    filtered = filtered.filter(item => item.price >= minPrice && item.price <= maxPrice);
    const selectedArtisans = Array.from(document.querySelectorAll('#artisanFilters input:checked')).map(cb => cb.value);
    if (selectedArtisans.length > 0) filtered = filtered.filter(item => item.type === 'product' ? selectedArtisans.includes(item.artisan) : true);

    const sortBy = document.getElementById('sortSelect').value;
    if (sortBy === 'price_asc') filtered.sort((a, b) => a.price - b.price);
    else if (sortBy === 'price_desc') filtered.sort((a, b) => b.price - a.price);
    displayResults(filtered);
  }

  function displayResults(results) {
    const grid = document.getElementById('resultsGrid');
    const resultsCount = document.getElementById('resultsCount');
    if (results.length === 0) {
      resultsCount.innerHTML = `<strong>0</strong> results found for <strong>"${currentSearchTerm}"</strong>`;
      grid.innerHTML = `<div class="no-results"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg><h3>No results found</h3><p>Try: "weaving", "pottery", "metalwork", "workshop"</p></div>`;
      return;
    }
    resultsCount.innerHTML = `<strong>${results.length}</strong> ${results.length === 1 ? 'result' : 'results'} found for <strong>"${currentSearchTerm}"</strong>`;
    grid.innerHTML = results.map(item => `
      <a href="${item.link}" class="product-card">
        <div class="pc-img">
          <<img src="${item.image}" alt="${item.name}">
          <span class="pc-badge ${item.type === 'workshop' ? 'gold' : ''}">${item.type === 'workshop' ? 'Workshop' : 'Product'}</span>
        </div>
        <div class="pc-body">
          <p class="pc-cat">${item.category}</p>
          <p class="pc-name">${item.name}</p>
          <p class="pc-name-ar">${item.nameAr}</p>
          <p class="pc-artisan">By: <strong>${item.artisan || 'Master Artisan'}</strong></p>
          ${item.location ? `<p class="pc-artisan" style="font-size:11px;">📍 ${item.location} ${item.date ? '· ' + item.date : ''}</p>` : ''}
          <div class="pc-footer"><span class="pc-price"><small>SAR</small> ${item.price}</span></div>
        </div>
      </a>
    `).join('');
  }

  function resetFilters() {
    document.querySelectorAll('#categoryFilters input, #artisanFilters input').forEach(cb => cb.checked = true);
    document.getElementById('filterProducts').checked = true;
    document.getElementById('filterWorkshops').checked = true;
    document.getElementById('minPrice').value = '0';
    document.getElementById('maxPrice').value = '2000';
    document.getElementById('sortSelect').value = 'relevance';
    applyFilters();
  }

  function performPageSearch() {
    const searchTerm = document.getElementById('searchPageInput').value;
    if (searchTerm.trim() !== '') window.location.href = 'search.php?q=' + encodeURIComponent(searchTerm);
  }

  function init() {
    currentSearchTerm = getSearchTermFromURL();
    const searchInput = document.getElementById('searchPageInput');
    if (searchInput) {
      searchInput.value = currentSearchTerm;
      searchInput.addEventListener('keypress', e => { if (e.key === 'Enter') performPageSearch(); });
    }
    if (currentSearchTerm && currentSearchTerm.trim() !== '') {
      currentResults = performSearch(currentSearchTerm);
      displayResults(currentResults);
    } else {
      document.getElementById('resultsCount').innerHTML = `<strong>0</strong> results found`;
      document.getElementById('resultsGrid').innerHTML = `<div class="no-results"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg><h3>Enter a search term</h3><p>Search for products, artisans, or workshops above</p></div>`;
    }
  }

  window.applyFilters = applyFilters;
  window.resetFilters = resetFilters;
  window.performPageSearch = performPageSearch;
  init();
</script>
<script>
  (function(){
    var link = document.getElementById('adminNavLink');
    if(!link) return;
    if(sessionStorage.getItem('adminLoggedIn')){
      link.textContent = '→ Admin Dashboard';
      link.href = 'admin-dashboard.php';
    }
  })();
</script>
<script src="cart.js"></script>
</body>
</html>